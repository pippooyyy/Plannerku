/**
 * Meong Planner - penyimpanan di Google Sheets.
 * Tempel seluruh isi file ini di Extensions > Apps Script, lalu ikuti PANDUAN.md.
 */

// GANTI dengan kode rahasia panjang buatanmu sendiri (jangan dibagikan ke siapa pun).
const TOKEN = 'GANTI_DENGAN_KODE_RAHASIAMU';

const SH = { t: 'Tugas', g: 'Goals', l: 'Catatan Goals', s: 'Seri Berulang', p: 'Pengaturan' };
const TH = {
  t: ['id', 'tanggal', 'mulai', 'selesai', 'judul', 'jenis', 'kategori', 'prioritas', 'status', 'alasan_tidak_terlaksana', 'catatan', 'seri_id', 'tanggal_asli', 'riwayat_reschedule'],
  g: ['id', 'judul', 'kategori', 'sub_tipe', 'target', 'satuan', 'tenggat'],
  l: ['goal_id', 'tanggal', 'nilai', 'durasi_menit', 'elevasi_m', 'catatan'],
  s: ['id', 'mulai', 'aturan', 'lewati', 'templat'],
  p: ['kunci', 'nilai']
};
const NUMCOLS = { g: [4], l: [2, 3, 4] }; // kolom angka (indeks mulai 0) agar bisa dipakai untuk grafik/rumus
const M = {
  c: { work: 'Kerja', life: 'Pribadi' },
  p: { h: 'Tinggi', m: 'Sedang', l: 'Rendah' },
  st: { todo: 'Rencana', doing: 'Dikerjakan', done: 'Selesai', gagal: 'Tidak terlaksana' },
  y: { task: 'Tugas', meeting: 'Meeting', olahraga: 'Olahraga', hangout: 'Hangout', event: 'Event' },
  gc: { sport: 'Olahraga', selfdev: 'Self Development' },
  gs: { run: 'Lari / Trail Run', swim: 'Renang', other_sport: 'Olahraga Lain', '': '' }
};
const inv = o => Object.fromEntries(Object.entries(o).map(([k, v]) => [v, k]));
const I = { c: inv(M.c), p: inv(M.p), st: inv(M.st), y: inv(M.y), gc: inv(M.gc), gs: inv(M.gs) };

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.token !== TOKEN) return out_({ ok: false, error: 'unauthorized' });
  if (p.action === 'load') {
    const lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try { return out_(load_()); } finally { lock.releaseLock(); }
  }
  return out_({ ok: true, pesan: 'Meong Planner siap' });
}

function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); } catch (x) { return out_({ ok: false, error: 'bad request' }); }
  if (body.token !== TOKEN) return out_({ ok: false, error: 'unauthorized' });
  if (body.action !== 'save' || !body.data) return out_({ ok: false, error: 'bad request' });
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return out_(save_(body.data)); } finally { lock.releaseLock(); }
}

// Jalankan fungsi ini sekali dari editor untuk memberi izin dan membuat tab beserta judul kolomnya.
function siapkan() {
  const ss = SpreadsheetApp.getActive();
  Object.keys(SH).forEach(k => { if (!ss.getSheetByName(SH[k])) write_(ss, k, []); });
}

function write_(ss, key, rows) {
  let sh = ss.getSheetByName(SH[key]);
  if (!sh) sh = ss.insertSheet(SH[key]);
  sh.clear();
  const h = TH[key], all = [h].concat(rows), num = NUMCOLS[key] || [];
  h.forEach((_, i) => { if (num.indexOf(i) < 0) sh.getRange(1, i + 1, all.length, 1).setNumberFormat('@'); }); // teks polos
  sh.getRange(1, 1, all.length, h.length).setValues(all);
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, h.length).setFontWeight('bold');
}

function save_(d) {
  const ss = SpreadsheetApp.getActive(), tasks = d.tasks || [], goals = d.goals || [], series = d.series || [];
  write_(ss, 't', tasks.map(x => [
    x.id, x.d || '', x.h || '', x.e || '', x.t || '', M.y[x.y || 'task'] || 'Tugas', M.c[x.c] || 'Kerja', M.p[x.p || 'm'] || 'Sedang',
    M.st[x.done ? 'done' : x.s === 'gagal' ? 'gagal' : x.s === 'doing' ? 'doing' : 'todo'], x.why || '', x.n || '', x.sid || '', x.od || '',
    x.rs && x.rs.length ? JSON.stringify(x.rs) : ''
  ]));
  write_(ss, 'g', goals.map(g => [g.id, g.t || '', M.gc[g.cat === 'sport' ? 'sport' : 'selfdev'], M.gs[g.sub || ''] || '', g.max || 0, g.u || '', g.dl || '']));
  const logs = [];
  goals.forEach(g => (g.log || []).forEach(l => logs.push([g.id, l.d || '', l.v || 0, l.dur || '', l.el || '', l.n || ''])));
  write_(ss, 'l', logs);
  write_(ss, 's', series.map(s => [s.id, s.start || '', JSON.stringify(s.rep || {}), JSON.stringify(s.skip || []), JSON.stringify(s.tpl || {})]));
  const updated = Date.now();
  write_(ss, 'p', [['theme', d.theme || 'lavender'], ['mode', d.mode || 'light'], ['id', d.id || 100], ['act', JSON.stringify(d.act || [])], ['updated', updated]]);
  return { ok: true, updated: updated };
}

function load_() {
  const ss = SpreadsheetApp.getActive(), tz = ss.getSpreadsheetTimeZone();
  const R = k => {
    const sh = ss.getSheetByName(SH[k]);
    if (!sh || sh.getLastRow() < 2) return [];
    return sh.getRange(2, 1, sh.getLastRow() - 1, TH[k].length).getValues();
  };
  const D = v => v instanceof Date ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : String(v == null ? '' : v).trim();
  const H = v => v instanceof Date ? Utilities.formatDate(v, tz, 'HH:mm') : String(v == null ? '' : v).trim();
  const S = v => String(v == null ? '' : v);
  const N = v => { const n = parseFloat(String(v).replace(',', '.')); return isNaN(n) ? 0 : n; };
  const J = v => { try { return v === '' || v == null ? undefined : JSON.parse(v); } catch (x) { return undefined; } };
  const idv = (v, i) => v === '' || v == null ? 'x' + Date.now() + i : /^\d+$/.test(String(v)) ? Number(v) : String(v);
  const rowsT = R('t').filter(r => S(r[4]) !== '' || S(r[0]) !== '');
  const tasks = rowsT.map((r, i) => {
    const st = I.st[S(r[8])] || 'todo', o = {
      id: idv(r[0], i), d: D(r[1]), h: H(r[2]), e: H(r[3]), t: S(r[4]), y: I.y[S(r[5])] || 'task', c: I.c[S(r[6])] || 'work',
      p: I.p[S(r[7])] || 'm', done: st === 'done' ? 1 : 0, s: st === 'doing' || st === 'gagal' ? st : '', why: S(r[9]), n: S(r[10]), rs: J(r[13]) || []
    };
    if (S(r[11])) { o.sid = S(r[11]); o.od = D(r[12]) || o.d; }
    return o;
  });
  const goals = R('g').filter(r => S(r[1]) !== '').map((r, i) => ({
    id: idv(r[0], i), t: S(r[1]), cat: I.gc[S(r[2])] || 'selfdev', sub: I.gs[S(r[3])] || '', max: N(r[4]), u: S(r[5]), dl: D(r[6]), log: []
  }));
  R('l').forEach(r => {
    const g = goals.find(x => String(x.id) === S(r[0]));
    if (!g || N(r[2]) <= 0) return;
    const l = { d: D(r[1]), v: N(r[2]), n: S(r[5]) };
    if (N(r[3]) > 0) l.dur = N(r[3]);
    if (N(r[4]) > 0) l.el = N(r[4]);
    g.log.push(l);
  });
  const series = R('s').filter(r => J(r[2]) && J(r[2]).t).map(r => ({ id: S(r[0]), start: D(r[1]), rep: J(r[2]), skip: J(r[3]) || [], tpl: J(r[4]) || {} }));
  const P = {};
  R('p').forEach(r => { P[S(r[0])] = r[1]; });
  const empty = !tasks.length && !goals.length && !series.length && !Object.keys(P).length;
  const data = { tasks: tasks, goals: goals, series: series, act: J(P.act) || [] };
  if (P.theme) data.theme = S(P.theme);
  if (P.mode) data.mode = S(P.mode);
  if (P.id) data.id = N(P.id);
  return { ok: true, empty: empty, data: data, updated: N(P.updated) };
}

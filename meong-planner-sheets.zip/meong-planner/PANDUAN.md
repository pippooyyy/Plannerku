# Panduan Pasang Meong Planner (Google Sheets + GitHub)

Hasil akhirnya: aplikasi terbuka di alamat GitHub Pages-mu, dan datanya tersimpan di Google Sheets milikmu. Tanpa login, tanpa server.

Isi folder:
- `index.html` : aplikasinya (satu file)
- `apps-script/Code.gs` : skrip yang menghubungkan aplikasi ke Google Sheets
- `PANDUAN.md` : panduan ini

---

## Bagian 1. Siapkan Google Sheets dan skripnya (sekitar 10 menit)

1. Buka sheets.google.com, buat spreadsheet baru. Beri nama bebas, misalnya "Meong Planner".
2. Di spreadsheet itu, klik menu **Extensions > Apps Script**.
3. Hapus semua isi editor, lalu tempel seluruh isi `apps-script/Code.gs`.
4. Cari baris ini di bagian atas:
   `const TOKEN = 'GANTI_DENGAN_KODE_RAHASIAMU';`
   Ganti isi di antara tanda kutip dengan kode rahasia panjang buatanmu (minimal 20 karakter, campuran huruf dan angka). Kamu bisa membuatnya lewat tombol "Buat kode acak" di aplikasi (lihat Bagian 3). Simpan kode ini di tempat aman.
5. Klik ikon simpan (Save).
6. Di dropdown fungsi (bagian atas editor), pilih **siapkan**, lalu klik **Run**.
   - Google akan meminta izin. Pilih akunmu. Jika muncul peringatan "Google hasn't verified this app", klik **Advanced**, lalu **Go to ... (unsafe)**. Ini wajar karena skrip ini kamu buat sendiri.
   - Setelah selesai, spreadsheet punya 5 tab: Tugas, Goals, Catatan Goals, Seri Berulang, Pengaturan.
7. Klik **Deploy > New deployment**.
   - Klik ikon roda gigi di samping "Select type", pilih **Web app**.
   - **Execute as**: Me (akunmu).
   - **Who has access**: **Anyone**. (Perlu supaya aplikasi bisa memanggilnya tanpa login Google. Data tetap dilindungi kode rahasia.)
   - Klik **Deploy**, lalu salin **Web app URL**. Alamatnya berawalan `https://script.google.com/macros/s/` dan berakhiran `/exec`.

Jangan bagikan URL dan kode rahasia itu ke siapa pun, termasuk di chat atau di GitHub.

## Bagian 2. Taruh aplikasi di GitHub Pages

1. Buat repository baru di akun GitHub-mu (misalnya `meong-planner`).
2. Unggah `index.html` ke akar repo (boleh lewat tombol "Add file > Upload files").
   Jangan unggah URL atau kode rahasia ke repo. Keduanya tidak ada di dalam file, dan hanya diketik di aplikasi.
3. Buka **Settings > Pages**. Pada "Build and deployment", pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu Save.
4. Tunggu beberapa menit. Alamatnya: `https://USERNAME.github.io/meong-planner/`.

Catatan: di akun GitHub gratis, GitHub Pages umumnya hanya untuk repo publik. Itu aman di sini karena file aplikasinya tidak berisi data atau kode rahasia. Kalau kamu ingin repo private, kamu bisa menghubungkan repo itu ke Cloudflare Pages (gratis, tanpa langkah build) dengan output directory `/`.

## Bagian 3. Sambungkan aplikasi ke Google Sheets

1. Buka aplikasi (dari alamat GitHub Pages atau dengan klik dua kali `index.html`).
2. Klik tombol **Sheets** di kanan atas.
3. Tempel **Web app URL** dan **kode rahasia** (sama persis dengan TOKEN di Code.gs).
   - Belum punya kode? Klik "Buat kode acak", salin kode itu ke baris TOKEN di Code.gs, simpan, lalu **Deploy > Manage deployments > ikon pensil > Version: New version > Deploy**. Setelah itu tempel kode yang sama di aplikasi.
4. Klik **Tes sambungan**. Hasil yang benar: "Terhubung ...".
5. Klik **Simpan dan sambungkan**.
   - Jika spreadsheet masih kosong, data di browser ini dikirim ke spreadsheet.
   - Jika spreadsheet dan browser sama-sama berisi data, aplikasi bertanya mana yang dipakai. OK = pakai data spreadsheet. Batal = kirim data browser ini dan timpa spreadsheet.
6. Ulangi langkah 2 sampai 5 di setiap perangkat lain (HP, laptop kedua). Data akan ikut muncul.

Status simpan terlihat di sidebar (di HP: di bawah judul halaman).

---

## Cara kerja dan hal yang perlu kamu tahu

- Aplikasi tetap bekerja instan di layar. Perubahan dikirim ke Sheets sekitar 1 detik setelahnya.
- Jika offline, perubahan tersimpan di browser dan otomatis terkirim saat tersambung lagi.
- Jika dua perangkat mengedit bersamaan, perubahan terakhir yang menang. Biasakan menutup satu perangkat sebelum memakai yang lain.
- Saat aplikasi dibuka, data dimuat dari Sheets. Kalau di perangkat itu ada perubahan yang belum terkirim, perubahan itu yang dikirim lebih dulu.
- Pengaman: data lokal yang kosong tidak pernah otomatis menimpa spreadsheet.

## Mengedit langsung di Google Sheets

Kamu boleh mengubah isi tab, lalu muat ulang aplikasi untuk melihat hasilnya. Aturannya:
- Kolom `status`: isi persis salah satu dari `Rencana`, `Dikerjakan`, `Selesai`, `Tidak terlaksana`.
- Kolom `kategori` (Tugas): `Kerja` atau `Pribadi`. `prioritas`: `Tinggi`, `Sedang`, `Rendah`.
- Kolom `jenis`: `Tugas`, `Meeting`, `Olahraga`, `Hangout`, `Event`.
- `tanggal`: format `2026-11-25`. `mulai` dan `selesai`: format `09:30`.
- Tab Catatan Goals: `durasi_menit` diisi angka menit (misalnya 32,5), bukan format jam. `goal_id` harus sama dengan `id` di tab Goals.
- Jangan ubah judul kolom (baris pertama), dan jangan hapus tab.
- Tab Seri Berulang dan Pengaturan berisi data teknis. Sebaiknya jangan diedit manual.
- Setiap aplikasi menyimpan, isi semua tab ditulis ulang dari data aplikasi. Karena itu, kalau kamu mengedit di Sheets, muat ulang aplikasi dulu sebelum mengubah apa pun di aplikasi.

## Pemecahan masalah

- "kode rahasia tidak cocok dengan Code.gs": kode di aplikasi berbeda dengan TOKEN di skrip. Setelah mengubah TOKEN, kamu harus Deploy versi baru.
- "tidak bisa menjangkau alamat": pastikan "Who has access" = Anyone, URL berakhiran `/exec` (bukan `/dev`), dan internet aktif.
- Perubahan skrip tidak berpengaruh: setiap kali Code.gs diubah, lakukan Deploy > Manage deployments > Edit > New version.
- Ingin berhenti memakai Sheets: klik Sheets > Putuskan. Data di browser tetap ada.
- Ingin menonaktifkan akses sepenuhnya: Deploy > Manage deployments > Archive, atau ganti TOKEN lalu deploy ulang.

## Keamanan singkat

- Siapa pun yang memegang URL dan kode rahasia bisa membaca dan menulis datamu. Perlakukan keduanya seperti password.
- URL dan kode hanya disimpan di browser perangkatmu (localStorage), tidak di GitHub.
- Skrip berjalan di akun Google-mu dan hanya mengakses spreadsheet yang terhubung dengannya.
- Jika kode bocor: ganti TOKEN, deploy versi baru, lalu perbarui kode di aplikasi.
